const express = require('express');
const path = require('path');
const cors = require('cors');  // CORS 패키지 추가
const app = express();
const port = 3000;

// CORS 설정
app.use(cors());

// 정적 파일 서빙
app.use(express.static(path.join(__dirname, 'public')));

// JSON 데이터 제공
app.get('/data', (req, res) => {
    const filePath = path.join(__dirname, 'data', 'data.json');
    res.sendFile(filePath, (err) => {
        if (err) {
            console.error('Error sending file:', err);
            res.status(err.status).end();
        }
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
